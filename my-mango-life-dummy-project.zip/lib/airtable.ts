// Airtable removed — using dummy content.
export const getEntries = async () => [];