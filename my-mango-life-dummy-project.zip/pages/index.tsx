
// /pages/index.tsx

import { useState } from 'react';
import Head from 'next/head';
import EntryCard from '../components/EntryCard';
import FilterBar from '../components/FilterBar';
import EntryModal from '../components/EntryModal';

const dummyEntries = [
  {
    id: '1',
    entryType: 'journal',
    contentType: 'home',
    title: 'Mango Morning',
    text: 'Woke up to sunlight and mangoes on the table.',
    imageUrl: '',
    pinned: true
  },
  {
    id: '2',
    entryType: 'quote',
    contentType: 'self',
    title: '',
    text: 'You smell like a home I miss.',
    imageUrl: '',
    pinned: false
  },
  {
    id: '3',
    entryType: 'photo',
    contentType: 'travel',
    title: 'Berbice View',
    text: '',
    imageUrl: 'https://images.unsplash.com/photo-1587502536263-3eaa3c7c1791',
    pinned: false
  },
  {
    id: '4',
    entryType: 'scrap',
    contentType: 'culture',
    title: 'Mashramani Vibes',
    text: 'Feathers, rhythm, joy, color.',
    imageUrl: '',
    pinned: true
  }
];

export default function Home() {
  const [entryTypeFilter, setEntryTypeFilter] = useState('all');
  const [contentTypeFilter, setContentTypeFilter] = useState('all');
  const [activeEntry, setActiveEntry] = useState(null);

  const filteredEntries = dummyEntries.filter((entry) => {
    const matchType = entryTypeFilter === 'all' || entry.entryType === entryTypeFilter;
    const matchContent = contentTypeFilter === 'all' || entry.contentType === contentTypeFilter;
    return matchType && matchContent;
  });

  const pinned = filteredEntries.filter((e) => e.pinned);
  const rest = filteredEntries.filter((e) => !e.pinned);

  return (
    <>
      <Head>
        <title>My Mango Life</title>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link
          href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap"
          rel="stylesheet"
        />
      </Head>
      <main className="bg-[#FFF4E0] min-h-screen p-4 font-quicksand">
        <h1 className="text-3xl font-pacifico text-[#5E463A] text-center mb-4">My Mango Life 🍋</h1>
        <div className="mb-4">
          <FilterBar type="entryType" active={entryTypeFilter} setActive={setEntryTypeFilter} />
          <FilterBar type="contentType" active={contentTypeFilter} setActive={setContentTypeFilter} />
        </div>
        <div className="grid grid-cols-2 gap-4">
          {[...pinned, ...rest].map((entry, i) => (
            <div
              key={entry.id}
              onClick={() => setActiveEntry(entry)}
              className={`transform transition duration-300 ease-in-out hover:scale-[1.015] hover:shadow-xl rounded-2xl ${
                i % 2 === 0 ? 'translate-y-1 rotate-[-1deg]' : 'translate-y-2 rotate-[1deg]'
              }`}
              style={{ boxShadow: '0 8px 24px rgba(0, 0, 0, 0.08)' }}
            >
              <EntryCard entry={entry} />
            </div>
          ))}
        </div>
        <EntryModal entry={activeEntry} onClose={() => setActiveEntry(null)} />
      </main>
    </>
  );
}
